# LifeQuest MVP

Telegram Mini App / React / Vite. This starter is a front-end prototype with localStorage persistence.

## Run locally
1. Install Node.js LTS on a computer: https://nodejs.org
2. Unzip the project.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open the localhost URL printed in terminal.

## Deploy free (Vercel)
1. Create a GitHub account and upload the project files to a new repository.
2. Sign up at https://vercel.com with GitHub.
3. Import the repository.
4. Framework preset: Vite; build command `npm run build`; output directory `dist`.
5. Deploy. Copy the HTTPS URL.

## Connect Telegram
1. In Telegram, open @BotFather and send `/newbot`; follow prompts to create a bot and copy its bot token (keep it private).
2. In BotFather, use `/setmenubutton`, select your bot, set button text (e.g. `Play LifeQuest`), and enter the deployed HTTPS URL.
3. Open your bot and tap its menu button to launch the Mini App.

## Notes
- The current app stores game state in the browser's localStorage. Different devices/browser sessions do not share data.
- Telegram user information is read from `initDataUnsafe` for display only. This MVP has no server-side verification; do not use it for valuable rewards or real payments.
- Stars payments, subscriptions, anti-cheat, account syncing, and server database are intentionally not implemented yet.
- No bot token is needed in the frontend. Never put a bot token into public JavaScript.
