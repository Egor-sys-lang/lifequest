import React, { useEffect, useMemo, useState } from 'react';

const TASKS = [
  { id: 'walk', title: 'Прогуляйся 20 минут', desc: 'Движение помогает прокачать тело', icon: '🚶', skill: 'Сила', xp: 35, coins: 12 },
  { id: 'read', title: 'Прочитай 10 страниц', desc: 'Прокачай знания и интеллект', icon: '📚', skill: 'Интеллект', xp: 30, coins: 10 },
  { id: 'focus', title: 'Сфокусируйся 25 минут', desc: 'Одна задача без отвлечений', icon: '🎯', skill: 'Дисциплина', xp: 45, coins: 15 },
  { id: 'water', title: 'Сделай паузу и выпей воды', desc: 'Маленькая забота о себе', icon: '💧', skill: 'Баланс', xp: 15, coins: 5 },
  { id: 'tidy', title: 'Наведи порядок 5 минут', desc: 'Улучши пространство вокруг себя', icon: '🧹', skill: 'Дисциплина', xp: 25, coins: 8 },
  { id: 'stretch', title: 'Растяжка 5 минут', desc: 'Разомнись и перезагрузись', icon: '🧘', skill: 'Сила', xp: 20, coins: 7 },
];

const ITEMS = [
  { id: 'plant', name: 'Комнатное растение', icon: '🪴', cost: 45, type: 'Декор', note: 'Уютный зелёный акцент' },
  { id: 'lamp', name: 'Лампа звёзд', icon: '🌟', cost: 80, type: 'Декор', note: 'Мягкий свет для комнаты' },
  { id: 'cat', name: 'Кот-компаньон', icon: '🐈', cost: 160, type: 'Питомец', note: 'Твой первый пушистый друг' },
  { id: 'books', name: 'Полка знаний', icon: '📚', cost: 110, type: 'Декор', note: 'Для героя, который учится' },
  { id: 'crown', name: 'Корона новичка', icon: '👑', cost: 220, type: 'Аксессуар', note: 'Покажи свой прогресс' },
  { id: 'flower', name: 'Садовая клумба', icon: '🌷', cost: 65, type: 'Декор', note: 'Добавь красок своему острову' },
];

const defaultState = {
  name: 'Путешественник',
  xp: 0, coins: 100, level: 1, streak: 0,
  completedToday: [],
  lastDay: '',
  owned: [],
  equipped: [],
  pet: '🐣',
  skills: { 'Сила': 0, 'Интеллект': 0, 'Дисциплина': 0, 'Баланс': 0, 'Финансы': 0 },
};

function localDayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function xpForLevel(level) { return 100 + (level - 1) * 35; }
function readSave() {
  try {
    const parsed = JSON.parse(localStorage.getItem('lifequest-save') || 'null');
    if (!parsed) return defaultState;
    const merged = { ...defaultState, ...parsed, skills: { ...defaultState.skills, ...(parsed.skills || {}) } };
    const today = localDayKey();
    if (merged.lastDay !== today) merged.completedToday = [];
    const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = `${yesterday.getFullYear()}-${String(yesterday.getMonth()+1).padStart(2,'0')}-${String(yesterday.getDate()).padStart(2,'0')}`;
    if (merged.lastDay && merged.lastDay !== today && merged.lastDay !== yesterdayKey) merged.streak = 0;
    return merged;
  } catch { return defaultState; }
}
function save(state) {
  try { localStorage.setItem('lifequest-save', JSON.stringify(state)); } catch {}
}
function tgUser() {
  try { return window.Telegram?.WebApp?.initDataUnsafe?.user; } catch { return null; }
}

export default function App() {
  const [data, setData] = useState(readSave);
  const [tab, setTab] = useState('home');
  const [toast, setToast] = useState('');
  const [showReset, setShowReset] = useState(false);
  const user = tgUser();

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      try { tg.setHeaderColor('#111522'); tg.setBackgroundColor('#111522'); } catch {}
    }
  }, []);

  useEffect(() => save(data), [data]);

  const completed = data.completedToday.length;
  const total = TASKS.length;
  const levelXp = xpForLevel(data.level);
  const progress = Math.min(100, (data.xp / levelXp) * 100);
  const dailyCoins = data.completedToday.reduce((sum, id) => sum + (TASKS.find(t => t.id === id)?.coins || 0), 0);

  function notify(message) {
    setToast(message);
    setTimeout(() => setToast(''), 2200);
    try { window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success'); } catch {}
  }

  function claimTask(task) {
    if (data.completedToday.includes(task.id)) return;
    const today = localDayKey();
    const isFirstTaskToday = data.lastDay !== today;
    const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = `${yesterday.getFullYear()}-${String(yesterday.getMonth()+1).padStart(2,'0')}-${String(yesterday.getDate()).padStart(2,'0')}`;
    const nextStreak = isFirstTaskToday ? (data.lastDay === yesterdayKey ? data.streak + 1 : 1) : data.streak;
    let nextXp = data.xp + task.xp;
    let nextLevel = data.level;
    let bonus = 0;
    while (nextXp >= xpForLevel(nextLevel)) {
      nextXp -= xpForLevel(nextLevel);
      nextLevel += 1;
      bonus += 50;
    }
    const skills = { ...data.skills, [task.skill]: (data.skills[task.skill] || 0) + 1 };
    setData(prev => ({
      ...prev,
      xp: nextXp, level: nextLevel, coins: prev.coins + task.coins + bonus,
      streak: nextStreak, lastDay: today, completedToday: [...prev.completedToday, task.id], skills
    }));
    notify(bonus ? `Задание выполнено! +${task.xp} XP · Уровень повышен! +${bonus}🪙` : `Задание выполнено! +${task.xp} XP`);
  }

  function buy(item) {
    if (data.owned.includes(item.id)) { notify('Уже куплено'); return; }
    if (data.coins < item.cost) { notify('Не хватает монет'); return; }
    setData(prev => ({ ...prev, coins: prev.coins - item.cost, owned: [...prev.owned, item.id] }));
    notify(`${item.name} добавлено в инвентарь`);
  }

  function equip(item) {
    const isOn = data.equipped.includes(item.id);
    setData(prev => ({ ...prev, equipped: isOn ? prev.equipped.filter(id => id !== item.id) : [...prev.equipped, item.id] }));
    notify(isOn ? 'Предмет убран' : 'Предмет размещён в мире');
  }

  function reset() {
    localStorage.removeItem('lifequest-save');
    setData(defaultState);
    setShowReset(false);
    notify('Прогресс сброшен');
  }

  const displayName = user?.first_name || data.name;
  const greeting = useMemo(() => {
    const h = new Date().getHours();
    return h < 12 ? 'Доброе утро' : h < 18 ? 'Добрый день' : 'Добрый вечер';
  }, []);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand"><span className="brand-icon">✦</span><div><b>LIFEQUEST</b><small>Твоя жизнь — твоя RPG</small></div></div>
        <button className="avatar-mini" onClick={() => setTab('profile')} aria-label="Профиль">🧙</button>
      </header>

      <main>
        {tab === 'home' && <Home data={data} setTab={setTab} completed={completed} total={total} progress={progress} levelXp={levelXp} dailyCoins={dailyCoins} greeting={greeting} displayName={displayName} claimTask={claimTask} />}
        {tab === 'quests' && <Quests data={data} claimTask={claimTask} />}
        {tab === 'world' && <World data={data} />}
        {tab === 'shop' && <Shop data={data} buy={buy} />}
        {tab === 'inventory' && <Inventory data={data} equip={equip} />}
        {tab === 'profile' && <Profile data={data} displayName={displayName} setShowReset={setShowReset} />}
      </main>

      <nav className="bottom-nav">
        {[
          ['home','🏠','Главная'], ['quests','⚔️','Квесты'], ['world','🌳','Мир'],
          ['shop','🛍️','Магазин'], ['inventory','🎒','Сумка']
        ].map(([id,icon,label]) => <button key={id} className={tab===id?'active':''} onClick={()=>setTab(id)}><span>{icon}</span><small>{label}</small></button>)}
      </nav>

      {toast && <div className="toast">{toast}</div>}
      {showReset && <div className="modal-backdrop"><div className="modal"><h3>Сбросить прогресс?</h3><p>Все уровни, монеты и покупки на этом устройстве будут удалены.</p><div className="modal-actions"><button className="btn-secondary" onClick={()=>setShowReset(false)}>Отмена</button><button className="btn-danger" onClick={reset}>Сбросить</button></div></div></div>}
    </div>
  );
}

function HeaderTitle({eyebrow, title, subtitle}) {
  return <div className="page-title"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>;
}

function Home({data,setTab,completed,total,progress,levelXp,dailyCoins,greeting,displayName,claimTask}) {
  return <>
    <section className="welcome"><div><span className="eyebrow">{greeting},</span><h1>{displayName} 👋</h1><p>Сегодня отличный день для нового уровня.</p></div><div className="streak"><span>🔥</span><b>{data.streak}</b><small>дней</small></div></section>
    <section className="hero-card">
      <div className="hero-top"><div className="level-pill">УРОВЕНЬ {data.level}</div><div className="coins">🪙 {data.coins}</div></div>
      <div className="hero-art"><div className="orbit orbit1"></div><div className="orbit orbit2"></div><div className="hero-character">🧙</div><div className="floating f1">✨</div><div className="floating f2">🌙</div><div className="floating f3">⭐</div></div>
      <div className="hero-bottom"><div><h2>Путь героя</h2><p>{levelXp-data.xp} XP до следующего уровня</p></div><span className="xp-label">{data.xp}/{levelXp}</span></div>
      <div className="progress-track"><div className="progress-fill" style={{width:`${progress}%`}}></div></div>
      <div className="hero-actions"><button className="btn-primary" onClick={()=>setTab('quests')}>Продолжить путь <span>→</span></button><button className="icon-button" onClick={()=>setTab('inventory')}>🎒</button></div>
    </section>
    <section className="stats-grid">
      <div className="stat-card"><span>⚡</span><strong>{data.xp}</strong><small>XP прогресс</small></div>
      <div className="stat-card"><span>🪙</span><strong>{dailyCoins}</strong><small>Монет получено</small></div>
      <div className="stat-card"><span>🎯</span><strong>{completed}/{total}</strong><small>Квестов сделано</small></div>
    </section>
    <section className="section">
      <div className="section-heading"><div><h2>Квесты на сегодня</h2><p>Маленькие шаги — большие изменения</p></div><button className="text-button" onClick={()=>setTab('quests')}>Все →</button></div>
      <div className="quest-list">
        {TASKS.slice(0,3).map(task=><TaskCard key={task.id} task={task} done={data.completedToday.includes(task.id)} onClaim={()=>claimTask(task)} compact />)}
      </div>
    </section>
    <section className="section promo-card" onClick={()=>setTab('world')}><div className="promo-emoji">🏡</div><div><h3>Твой мир ждёт</h3><p>Укрась дом и создай уютное место.</p></div><span>→</span></section>
  </>;
}

function Quests({data,claimTask}) {
  return <><HeaderTitle eyebrow="ЕЖЕДНЕВНАЯ АКТИВНОСТЬ" title="Квесты" subtitle="Выбирай реальные действия и получай награды."/><div className="quest-summary"><div><strong>{data.completedToday.length}/{TASKS.length}</strong><span>заданий завершено</span></div><div className="quest-summary-icon">🗺️</div></div><div className="quest-list">{TASKS.map(task=><TaskCard key={task.id} task={task} done={data.completedToday.includes(task.id)} onClaim={()=>claimTask(task)} />)}</div><div className="tip-card">💡 <span>Выбирай выполнимые задания. Главное — постоянство, а не идеальный день.</span></div></>;
}

function TaskCard({task,done,onClaim,compact=false}) {
  return <div className={`task-card ${done?'done':''} ${compact?'compact':''}`}><div className="task-icon">{task.icon}</div><div className="task-info"><h3>{task.title}</h3><p>{task.desc}</p><div className="rewards"><span>⚡ +{task.xp} XP</span><span>🪙 +{task.coins}</span></div></div><button className={done?'claimed':'claim-button'} onClick={onClaim} disabled={done}>{done?'✓':compact?'＋':'Забрать'}</button></div>;
}

function World({data}) {
  const decor = data.equipped.map(id=>ITEMS.find(i=>i.id===id)).filter(Boolean);
  return <><HeaderTitle eyebrow="ТВОЁ ПРОСТРАНСТВО" title="Мой мир" subtitle="Мир растёт вместе с твоими достижениями."/><div className="world-scene"><div className="sun">☀️</div><div className="cloud cloud-a">☁️</div><div className="cloud cloud-b">☁️</div><div className="mountains">⛰️</div><div className="world-house">🏡</div><div className="world-tree">🌳</div><div className="world-ground"></div><div className="world-player">🧙</div>{decor.map((item,i)=><div key={item.id} className={`placed p${i}`}>{item.icon}</div>)}</div><div className="world-info"><div><span className="eyebrow">ТВОЙ УРОВЕНЬ</span><h2>Уровень {data.level}</h2></div><div className="world-stat">🪙 {data.coins}</div></div><div className="section"><div className="section-heading"><div><h2>Украшения</h2><p>Предметы из твоей коллекции</p></div></div>{decor.length? <div className="owned-decor">{decor.map(item=><div className="decor-chip" key={item.id}>{item.icon} {item.name}</div>)}</div>:<div className="empty-card"><div>🌱</div><h3>Пока пусто</h3><p>Купи декор в магазине и размести его здесь из инвентаря.</p></div>}</div></>;
}

function Shop({data,buy}) {
  return <><HeaderTitle eyebrow="ОБМЕН МОНЕТ" title="Магазин" subtitle="Собирай предметы и делай свой мир уникальным."/><div className="wallet-card"><span>Твой баланс</span><strong>🪙 {data.coins}</strong><small>Монеты за квесты — пока бесплатная игровая валюта.</small></div><div className="shop-grid">{ITEMS.map(item=>{const owned=data.owned.includes(item.id);return <div className="shop-item" key={item.id}><div className="item-art">{item.icon}<span className="item-type">{item.type}</span></div><h3>{item.name}</h3><p>{item.note}</p><button className={owned?'owned-button':'buy-button'} disabled={owned||data.coins<item.cost} onClick={()=>buy(item)}>{owned?'✓ Куплено':`🪙 ${item.cost}`}</button></div>})}</div><div className="disclaimer">В этой версии предметы покупаются только за игровую валюту. Платежи Telegram Stars подключим после тестирования игрового баланса.</div></>;
}

function Inventory({data,equip}) {
  const owned=ITEMS.filter(i=>data.owned.includes(i.id));
  return <><HeaderTitle eyebrow="СОБРАННЫЕ ПРЕДМЕТЫ" title="Инвентарь" subtitle="Твои коллекции и вещи."/><div className="inventory-count">Предметов: <b>{owned.length}</b></div>{owned.length===0?<div className="empty-card"><div>🎒</div><h3>Инвентарь пуст</h3><p>Выполняй квесты, собирай монеты и загляни в магазин.</p></div>:<div className="shop-grid">{owned.map(item=><div className="shop-item" key={item.id}><div className="item-art">{item.icon}<span className="item-type">{item.type}</span></div><h3>{item.name}</h3><p>{item.note}</p><button className={data.equipped.includes(item.id)?'owned-button':'buy-button'} onClick={()=>equip(item)}>{data.equipped.includes(item.id)?'Убрать из мира':'Разместить'}</button></div>)}</div>}<div className="pet-card"><div className="pet-emoji">{data.owned.includes('cat')?'🐈':data.pet}</div><div><h3>Питомец</h3><p>{data.owned.includes('cat')?'Кот теперь живёт с тобой!':'Пока у тебя нет питомца. Купи кота в магазине.'}</p></div></div></>;
}

function Profile({data,displayName,setShowReset}) {
  const skills=Object.entries(data.skills);
  return <><HeaderTitle eyebrow="ТВОЙ ПУТЬ" title="Профиль" subtitle="Каждый шаг — часть твоей истории."/><div className="profile-card"><div className="profile-avatar">🧙</div><h2>{displayName}</h2><span className="level-pill">УРОВЕНЬ {data.level}</span><div className="profile-numbers"><div><b>{data.level}</b><small>Уровень</small></div><div><b>{data.coins}</b><small>Монеты</small></div><div><b>{data.owned.length}</b><small>Предметы</small></div></div></div><section className="section"><div className="section-heading"><div><h2>Навыки</h2><p>Растут от выполненных заданий</p></div></div><div className="skills-list">{skills.map(([name,value])=><div className="skill-row" key={name}><div className="skill-name"><span>{({Сила:'💪',Интеллект:'🧠',Дисциплина:'🎯',Баланс:'🌿',Финансы:'💰'})[name]}</span><b>{name}</b><strong>{value}</strong></div><div className="progress-track"><div className="progress-fill" style={{width:`${Math.min(100,value*10)}%`}}/></div></div>)}</div></section><div className="about-card"><h3>О LifeQuest</h3><p>Превращай реальные полезные действия в игровой прогресс. Эта ранняя версия хранит сохранение на устройстве.</p><button className="reset-link" onClick={()=>setShowReset(true)}>Сбросить игровой прогресс</button></div></>;
}